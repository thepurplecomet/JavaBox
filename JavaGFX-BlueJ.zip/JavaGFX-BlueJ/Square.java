public class Square extends Polygon3D
{
    public Square(){
        Point3D[] points = new Point3D[4];
        points[0] = new Point3D(0,1,1);
        points[1] = new Point3D(0,1,-1);
        points[2] = new Point3D(0,-1,-1);
        points[3] = new Point3D(0,-1,1);
    }
    public Square(double scale){
        Point3D[] points = new Point3D[4];
        points[0] = new Point3D(0,(int)scale/2,(int)scale/2);
        points[1] = new Point3D(0,(int)scale/2,(int)-scale/2);
        points[2] = new Point3D(0,-(int)scale/2,-(int)scale/2);
        points[3] = new Point3D(0,-(int)scale/2,(int)scale/2);
    }
}
