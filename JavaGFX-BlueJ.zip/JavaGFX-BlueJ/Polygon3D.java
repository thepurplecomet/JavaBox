public class Polygon3D

{
    private Point3D[] points;
    
    public Polygon3D(Point3D... points){
        this.points = points;
    }
    
    public Point3D[] getPolyArray(){
        return this.points;
    }
    
    public void setPolyArray(Point3D[] newArray){
        this.points = newArray;
    }
    
    public Point3D getPoint3D(int i){
        return this.points[i];
    }
    
    public void setPoint3D(int i,Point3D newPoint){
        this.points[i] = newPoint;
    }
}
