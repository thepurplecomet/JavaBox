import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

public class Main
{
    public static void main(){
        JavaBox window = new JavaBox(400,400,true);
        window.isVisible(true);
        window.addGrid();
        Cube3D cube1 = new Cube3D(100,Color.BLUE);
        window.getGrid().renderPerspMesh3D(cube1);
        
    }
}